package com.example.dao;

public interface ImageDao 
{
	

}
