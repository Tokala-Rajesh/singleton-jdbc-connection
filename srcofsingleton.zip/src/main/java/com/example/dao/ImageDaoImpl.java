package com.example.dao;

public class ImageDaoImpl implements ImageDao
{

}
